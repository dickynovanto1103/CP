#include <cstdio>
 
const int MOD = 1000000007;

int k(int x) {
    while (x < 0) x += MOD;
    while (x >= MOD) x -= MOD;
    return x;
}

int j(int x, int y) {
    int z = y;
    while (x --> 0) {
        z --> 0;
        z = k(z);
    }
    return z;
}

int i(int x, int y) {
    int z = y;
    while (x --> 0) {
        int w = MOD;
        w --> 0;
        z = j(w, z);
        z = k(z);
    }
    return z;
}

int h(int x, int y) {
    int z = 0;
    while (y --> 0)
        z = i(x, z);
    return z;
}

int g(int x, int y, int z) {
    int w = 0;
    w = h(x, y);
    w = i(h(y, y), w);
    w = j(h(i(x, y), z), w);
    return w;
}

int f(int x, int y) {
    int z = 0;
    while (x --> 0)
        z = g(z, x, y);
    return z;
}

int main() {
    int t, n, m;
    scanf("%d", &t);
    while (t --> 0) {
        scanf("%d %d", &n, &m);
        printf("%d\n", f(n, m));
    }
    return 0;
}
